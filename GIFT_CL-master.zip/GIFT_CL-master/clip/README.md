This folder is a lightly modified version of https://github.com/openai/CLIP.
